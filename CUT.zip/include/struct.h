/*
struct.h is the header file in which all the macros are defined.
*/


#define pfname_len 100
#define plname_len 20
#define pusername_len 20
#define ppassword_len 20
#define rfname_len 100
#define rlname_len 20
#define rusername_len 20
#define rpassword_len 20
#define max 20
#define cost_len 10
//#define FILENAME_SIZE 1024
//#define MAX_LINE 2048


